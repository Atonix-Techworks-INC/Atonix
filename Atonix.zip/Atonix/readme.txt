                                                               Welcome To Atonix

First off, if you need help join our discord server by using this link: https://dsc.gg/atonix

--------------------------------------------------------------------------------------------

What Is Atonix?

Atonix is a Premium Roblox Lua Utility/Executor that you can use to execute Lua scripts inside your favorite
Roblox Games

-

Common Issues & Fixes:

Required Dependencies

VC Redist x64: https://aka.ms/vs/16/release/vc_redist.x64.exe
VC Redist x86: https://aka.ms/vs/16/release/vc_redist.x86.exe
ttps://dotnet.microsoft.com/en-us/download/dotnet-framework/thank-you/net48-web-installer
All are by microsoft and are not viruses

-

"Exploit Is Currently Patched Error"

This means ROBLOX has patched the WRD api, please switch to a different API via the settings or wait for 
it to be fixed

-

"Atonix gives an error then crashes"
Check the logs folder, and open the most recent file.

Follow these steps to fix the error:

1. Copy the first line inside the text file and paste it into your browser
2. Look for fixes on the error
3. If you cannot self-fix it then join our discord server located at the top of this document and ask us for
help inside the support channels

-

"WeAreDevs API is outdated error after launching"

Either wait for us to fix it or use a different API (Reccomended)

-

"My error isn't listed"

Join our discord server and ask in the support channels for help:
https://dsc.gg/atonix

--------------------------------------------------------------------------------------------

Credits:

Owner: Soulzay
Developer: Nam3
API Developer: JoeIsGod